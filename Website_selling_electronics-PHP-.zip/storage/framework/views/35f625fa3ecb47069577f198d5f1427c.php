<!doctype html>
<html class="no-js" lang="zxx">
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>ROBOCON</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo.png')); ?>">
    </head>
    <body>
        <div class="body-wrapper">
            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="breadcrumb-area">
                <div class="container">
                    <div class="breadcrumb-content">
                        <ul>
                            <li>Trang chủ</li>
                            <li class="active">Bài viết</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="li-main-blog-page pt-60 pb-55">
                <div class="container">
                    <div class="row">
                        <div class="col-lg order-1">
                            <div class="row li-main-content">
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="li-blog-single-item pb-25">
                                        <div class="li-blog-banner">
                                            <a href="<?php echo e(route('article.show', $article->id)); ?>"><img class="img-full" src="images\articles\<?php echo e($article->image); ?>" alt="Bài viết số <?php echo e($article->id); ?>"></a>
                                        </div>
                                        <div class="li-blog-content" style="word-wrap: break-word;">
                                            <div class="li-blog-details">
                                                <h3 class="li-blog-heading pt-25"><a href="<?php echo e(route('article.show', $article->id)); ?>"><?php echo e($article->title); ?></a></h3>
                                                <div class="li-blog-meta">
                                                    <a class="author" href=""><i class="fa fa-user"></i>Admin</a>
                                                    <a class="comment" href=""><i class="fa fa-comment-o"></i> 3 bình luận</a>
                                                    <a class="post-time" href=""><i class="fa fa-calendar"></i>  <?php echo e($article->created_at->day); ?>/<?php echo e($article->created_at->month); ?>/<?php echo e($article->created_at->year); ?></a>
                                                </div>
                                                <p><?php echo e(Str::limit($article->content, 120)); ?>...</p>
                                                <a class="read-more" href="<?php echo e(route('article.show', $article->id)); ?>">Đọc tiếp...</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                            </div> 
                            <div class="d-flex justify-content-center">
                                <?php echo e($articles->links('pagination::bootstrap-4')); ?>

                            </div>                                                   
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Website_selling_electronics-PHP-\resources\views/articles/articles.blade.php ENDPATH**/ ?>