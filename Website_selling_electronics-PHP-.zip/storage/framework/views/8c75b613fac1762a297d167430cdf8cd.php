<h3>Danh sách Sản Phẩm</h3>
<div class="container mt-3">
    <div class="row mb-3">
        <div class="col-md-5">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Nhập tên sản phẩm">
                <button class="btn btn-primary">Tìm kiếm</button>
            </div>
        </div>
        <div class="col-md-6 text-end">
    <a href="" class="btn btn-success" id="add-new-product-btn">
        <i class="bi bi-plus-circle-fill"></i> <span>Thêm mới</span>
    </a>                  
</div>
<div id="dynamic-content"></div> 

    </div>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>STT</th>
            <th>Tên Sản Phẩm</th>
            <th>Giá bán</th>
            <th>Số lượng</th>
            <th>Hình ảnh</th>
            <th>Giá mua</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->id); ?></td>
                <td><?php echo e($product->name); ?></td>
                <td><?php echo e(number_format($product->sale_price, 0, ',', '.')); ?> VNĐ</td>
                <td><?php echo e($product->quantity); ?></td>
                <td>
                    <img src="<?php echo e(asset('images/product/'.$product->image )); ?>" alt="Li's Product Image" style="width: 100px; height: auto;">
                </td>
                <td><?php echo e(number_format($product->purchase_price, 0, ',', '.')); ?> VNĐ</td>
                <td >
                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" id="edit-product-btn-<?php echo e($product->id); ?>">
                        <i class="bi bi-pencil-fill edit-icon" style="color: #FFC107;"></i>
                    </a>
                    <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post" 
                        onsubmit="return confirm('Bạn có chắc chắn muốn xóa mục này?');" 
                        style="display: inline-block; margin-left: 5px;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" style="border: none; background: none; padding: 0; cursor: pointer;">
                            <i class="bi bi-trash3-fill delete-icon" style="color: red"></i>
                        </button>
                    </form>
                </td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($products->links('pagination::bootstrap-4')); ?>

<script>
   $(document).ready(function() {
    $("#add-new-product-btn").click(function(e) {
        e.preventDefault(); 
        $.ajax({
            url: '/add-products', 
            method: 'GET',
            success: function(data) {
                $("#dynamic-content").html(data);
            },
            error: function(xhr) {
                alert("Đã xảy ra lỗi, vui lòng thử lại!");
            }
        });
    });

    $(document).on("click", "[id^='edit-product-btn-']", function(e) {
        e.preventDefault(); 
        var productId = $(this).attr('id').split('-').pop();  
        $.ajax({
            url: '/edit-products/' + productId, 
            method: 'GET',
            success: function(data) {
                $("#dynamic-content").html(data); 
            },
            error: function(xhr) {
                alert("Đã xảy ra lỗi, vui lòng thử lại!");
            }
        });
    });
});

</script>

<?php /**PATH C:\xampp\htdocs\Website_selling_electronics-PHP-\resources\views/administrator/products/products.blade.php ENDPATH**/ ?>