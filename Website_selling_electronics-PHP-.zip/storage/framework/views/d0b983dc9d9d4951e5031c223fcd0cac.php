    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/material-design-iconic-font.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-stars.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/meanmenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/venobox.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/helper.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">
    <script src="<?php echo e(asset('js/vendor/modernizr-2.8.3.min.js')); ?>"></script>

    
<header class="li-header-4" style="background-color:#263b96;">
                <div class="header-middle pl-sm-0 pr-sm-0 pl-xs-0 pr-xs-0">
                    <div class="container" >
                        <div class="row">
                            <div class="col-lg-2">
                                <div class="logo pb-sm-30 pb-xs-30">
                                    <a href="<?php echo e(route('welcome')); ?>"> <img src="<?php echo e(asset('images/logo.png')); ?>"  style="width: 80px;" alt=""></a>
                               
                                </div>
                            </div>
                            <div class="col-lg-10 pl-0 ml-sm-15 ml-xs-15">
                                <form action="" class="hm-searchbox">
                                    <input type="text" placeholder="Enter your search key ...">
                                    <button class="li-btn" type="submit"><i class="fa fa-search"></i></button>
                                </form>
                                <div class="header-middle-right">
                                    <ul class="hm-menu" style="display: flex;">                                       
                                        <li class="hm-minicart">
                                            <div class="hm-minicart-trigger" style="background-color:#263b96;">
                                                <span class="item-icon"></span>
                                                <span class="item-text">Giỏ hàng
                                                <span class="badge" style="font-size: 15px;"><?php echo e($totalQuantity); ?></span>
                                                </span>
                                            </div>                                         
                                            <div class="minicart">
                                                <ul class="minicart-product-list">
                                                    <?php $__currentLoopData = $cartItems ?? collect(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('product.show', $cartItem->product->id)); ?>" class="minicart-product-image">
                                                            <img src=" <?php echo e(asset ('images/product/'.$cartItem->product->image)); ?>" alt="cart products">
                                                        </a>
                                                        <div class="minicart-product-details d-flex">
                                                            <div>
                                                                <h6><a href=""></a><?php echo e($cartItem->product->name); ?></h6>
                                                                <span><?php echo e(number_format($cartItem->price, 0, ',', '.')); ?> VNĐ</span>
                                                            </div>
                                                            <span class="quantity" style="margin-left: auto; padding-left: 10px;">x<?php echo e($cartItem->quantity); ?></span>
                                                        </div>
                                                        <style>
                                                        .minicart-product-details {
                                                            display: flex;
                                                            justify-content: space-between;  
                                                            align-items: center;  
                                                        }

                                                        .quantity {
                                                            margin-left: 15px;  
                                                            padding-left: 10px; 
                                                        }
                                                        </style>
                                                        <button class="close">
                                                            <a href="<?php echo e(route('cart.remove', $cartItem->id)); ?>"><i class="fa fa-close"></i></a>
                                                            
                                                        </button>
                                                    </li> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                   
                                                </ul>
                                                <p class="minicart-total">Tổng tiền: <span><?php echo e(number_format($totalAmount, 0, ',', '.')); ?>VNĐ</span></p>
                                                <div class="minicart-button">
                                                    <a href="<?php echo e(route('shopping.cart')); ?>" class="li-button li-button-dark li-button-fullwidth li-button-sm">
                                                        <span>Giỏ hàng</span>
                                                    </a>
                                                    <a href="<?php echo e(route('shopping.checkout')); ?>" class="li-button li-button-fullwidth li-button-sm">
                                                        <span>Thanh toán</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="hm d-flex" style="align-items: center; ">
                                            <?php if(Route::has('login')): ?>
                                                <?php if(auth()->guard()->check()): ?> 
                                                <span class="bi bi-person-circle" style="color:white; font-size:20px ;"></span>                               
                                                <div class="hm-minicart-trigger" style="background-color:#263b96;">
                                                    <span class="item-text"><?php echo e(Str::limit(Auth::user()->name, 8)); ?></span>
                                                </div>                                          
                                            <div class="minicart">
                                                <ul class="minicart-product-list">
                                                    <?php if($role === 'admin'): ?>
                                                        <li>
                                                            <a class="dropdown-item" href="<?php echo e(route('admin')); ?>" style="color: black;">
                                                                Quản trị trang web
                                                            </a>
                                                        </li>                                                   
                                                    <?php endif; ?>
                                                    <li>
                                                    <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>" style="color: black;">
                                                        Hồ sơ
                                                    </a>
                                                    </li>                                                                     
                                                    <li>  
                                                        <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin-top: 0.1rem;">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="dropdown-item" style="background: none; border: none; color: black;">
                                                                    Đăng xuất
                                                                </button>
                                                        </form>                                                 
                                                    </li>
                                                </ul>
                                            </div>
                                                <?php else: ?>
                                                    <div class="d-flex" style="margin-top: 0.4rem;">
                                                        <a href="<?php echo e(route('login')); ?>" class="d-flex justify-content-center align-items-center text-white text-decoration-none" style="height: 100%; margin-right: 1rem; color: #ffffff; font-size: 1rem;">
                                                            <?php echo e(__('Đăng Nhập')); ?>

                                                        </a>

                                                        <?php if(Route::has('register')): ?>
                                                            <a href="<?php echo e(route('register')); ?>" class="d-flex justify-content-center align-items-center text-white text-decoration-none" style="height: 100%; color: #ffffff; font-size: 1rem;">
                                                                <?php echo e(__('Đăng Ký')); ?>

                                                            </a>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </li>

                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="header-bottom header-sticky stick d-none d-lg-block d-xl-block" style="background-color:#fdfdfd;" >
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                               <div class="hb-menu d-flex justify-content-center" style="margin:0 auto;">
                                   <nav>
                                       <ul >
                                           <li  class="dropdown-holder"><a href="<?php echo e(route('welcome')); ?>" style="color:#263b96;">Trang Chủ</li>                                          
                                           <li class="megamenu-holder"><a href="<?php echo e(route('products')); ?>" style="color:#263b96;">Sản phẩm</a>
                                               <ul class="megamenu hb-megamenu">
                                                   <li><a href="">Sản Phẩm</a>
                                                           <ul>                                            
                                                           <li><a href=""></a></li>                                                                                                        
                                                           </ul>
                                                   </li>                                                      
                                               </ul>
                                           </li>
                                           <li class=""><a href="<?php echo e(route('articles')); ?>" style="color:#263b96;">BÀI VIẾT</a></li>
                                           <li class=""><a href="<?php echo e(route('introduction')); ?>" style="color:#263b96;">GIỚI THIỆU</a></li>
                                           <li class="megamenu-static-holder"><a href="<?php echo e(route('documents')); ?>" style="color:#263b96;">Tư liệu tham khảo</a>
                                               
                                           </li>
                                                
                                       </ul>
                                   </nav>
                               </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
<div id="chat-widget" class="chat-widget">
    <button id="chat-btn" class="chat-btn">
        <i class="bi bi-chat-dots"></i> 
    </button>
    <div id="chat-box" class="chat-box">
        <div class="chat-header">
            <span>Hỗ trợ khách hàng</span>
            <button id="close-chat" class="close-chat">X</button>
        </div>
        <div class="chat-messages" id="chat-messages">
        </div>
        <div class="chat-input">
            <input type="text" id="message-input" placeholder="Nhập tin nhắn...">
            <button onclick="sendMessage()">Gửi</button>
        </div>
    </div>
</div>

<style>
.chat-widget {
    position: fixed;
    bottom: 100px;
    right: 20px;
    z-index: 9999;
}

.chat-btn {
    background-color: #007bff;
    border: none;
    border-radius: 50%;
    width: 60px;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 30px; 
    color: white;
    cursor: pointer;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.chat-btn:hover {
    background-color: #0056b3;
    transform: scale(1.1);
}

.chat-box {
    display: none;
    position: fixed;
    bottom: 90px;
    right: 20px;
    background-color: white;
    width: 320px;
    height: 450px;
    border-radius: 15px;
    box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.2);
    overflow: hidden;
    flex-direction: column;
    box-sizing: border-box;
    animation: slideIn 0.3s ease-out;
}

.chat-header {
    background-color: #007bff;
    color: white;
    padding: 10px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.close-chat {
    background-color: transparent;
    border: none;
    color: white;
    cursor: pointer;
    font-size: 18px;
}

.chat-messages {
    padding: 10px;
    overflow-y: auto;
    flex-grow: 1;
    max-height: 300px;
}

.chat-input {
    display: flex;
    padding: 10px;
    background-color: #007bff;
    border-top: 1px solid #ddd;
}

.chat-input input {
    flex-grow: 1;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ddd;
}

.chat-input button {
    background-color: #007bff;
    border: none;
    color: white;
    padding: 10px;
    border-radius: 5px;
    cursor: pointer;
}

.chat-input button:hover {
    background-color: #128c7e;
}

.message {
    margin: 10px 0;
    padding: 8px;
    background-color: #f1f1f1;
    border-radius: 4px;
    max-width: 80%;
}

.message.sent {
    background-color: #dcf8c6;
    align-self: flex-end;
}

.message.received {
    background-color: #f1f1f1;
    align-self: flex-start;
}


</style>
<script>
document.getElementById("chat-btn").addEventListener("click", function() {
    const chatBox = document.getElementById("chat-box");
    chatBox.style.display = chatBox.style.display === "none" ? "flex" : "none";
});

document.getElementById("close-chat").addEventListener("click", function() {
    const chatBox = document.getElementById("chat-box");
    chatBox.style.display = "none";
});

function sendMessage() {
    const messageInput = document.getElementById("message-input");
    const messageText = messageInput.value.trim();

    if (messageText) {
        const chatMessages = document.getElementById("chat-messages");
        const messageElement = document.createElement("div");
        messageElement.classList.add("message", "sent");
        messageElement.textContent = messageText;
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        setTimeout(() => {
            const responseMessage = document.createElement("div");
            responseMessage.classList.add("message", "received");
            responseMessage.textContent = "Chúng tôi sẽ trả lời bạn sớm.";
            chatMessages.appendChild(responseMessage);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 1000);

        messageInput.value = '';
    }
}
</script><?php /**PATH C:\xampp\htdocs\Website_selling_electronics-PHP-\resources\views/layouts/header.blade.php ENDPATH**/ ?>