<!doctype html>
<html class="no-js" lang="vi">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>ROBOCON</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo.png')); ?>">
</head>
<body>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="body-wrapper">
        <div class="breadcrumb-area">
            <div class="container">
                <div class="breadcrumb-content">
                    <ul>
                        <li>Trang Chủ</li>
                        <li class="active">Giỏ Hàng</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="Shopping-cart-area pt-60 pb-60">
            <div class="container">
                <div class="row">
                <div class="col-12">
    <form action="<?php echo e(route('shopping.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="table-content table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th class="li-product-remove">Xóa</th>
                        <th class="li-product-thumbnail">Hình ảnh</th>
                        <th class="cart-product-name">Sản phẩm</th>
                        <th class="li-product-price">Đơn giá</th>
                        <th class="li-product-quantity">Số lượng</th>
                        <th class="li-product-subtotal">Tổng cộng</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="li-product-remove">
                            <a href="<?php echo e(route('cart.remove', $cartItem->id)); ?>"><i class="fa fa-times"></i></a>
                        </td>
                        <td class="li-product-thumbnail">
                            <a href="<?php echo e(route('product.show', $cartItem->product->id)); ?>"><img src="<?php echo e(asset('images/product/'.$cartItem->product->image)); ?>" alt="Hình ảnh sản phẩm Li" style="width:150px"></a>
                        </td>
                        <td class="li-product-name"><a href="<?php echo e(route('product.show', $cartItem->product->id)); ?>"><?php echo e($cartItem->product->name); ?></a></td>
                        <td class="li-product-price">
                            <span class="amount"><?php echo e(number_format($cartItem->price, 0, ',', '.')); ?> VNĐ</span>
                        </td>
                        <td class="quantity">
                            <label>Số lượng</label>
                            <div class="cart-plus-minus">
                                <input class="cart-plus-minus-box" name="quantities[<?php echo e($cartItem->id); ?>]" value="<?php echo e($cartItem->quantity); ?>" type="number" min="1">
                                <div class="dec qtybutton"><i class="fa fa-angle-down"></i></div>
                                <div class="inc qtybutton"><i class="fa fa-angle-up"></i></div>
                            </div>
                        </td>
                        <td class="product-subtotal">
                            <span class="amount"><?php echo e(number_format($cartItem->quantity * $cartItem->price, 0, ',', '.')); ?> VNĐ</span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="coupon-all">
                    <div class="coupon">
                        <input id="coupon_code" class="input-text" name="coupon_code" value="" placeholder="Mã giảm giá" type="text">
                        <input class="button" name="apply_coupon" value="Áp dụng mã" type="submit">
                    </div>
                    <div class="coupon2">
                        <input class="button" name="update_cart" value="Cập nhật giỏ hàng" type="submit">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5 ml-auto">
                <div class="cart-page-total">
                    <h2>Tổng giỏ hàng</h2>
                    <ul>
                        <li>Tạm tính <span><?php echo e(number_format($totalAmount, 0, ',', '.')); ?> VNĐ</span></li>
                        <li>Tổng cộng <span><?php echo e(number_format($totalAmount, 0, ',', '.')); ?> VNĐ</span></li>
                    </ul>
                    <a href="<?php echo e(route('shopping.checkout')); ?>">Thanh toán</a>
                </div>
            </div>
        </div>
    </form>
</div>

                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Website_selling_electronics-PHP-\resources\views/products/shoppingCart.blade.php ENDPATH**/ ?>